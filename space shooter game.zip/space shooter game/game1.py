#linked list 
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        
class LinkedList:
    def __init__(self):
        self.head=None
    def push_at_end(self, value):
        temp = self.head
        new_node = Node(value)
        if not temp:
            temp = new_node
            return 
        while temp.next:
            temp=temp.next
        temp.next = new_node
        return 
    def printlist(self):
        temp= self.head
        while temp:
            print(temp.data, end = " -> ")
            temp = temp.next
ll=LinkedList()
ll.push_at_end(1)
ll.push_at_end(2)
ll.push_at_end(3)
ll.push_at_end(4)
ll.push_at_end(5)
ll.push_at_end(6)
ll.push_at_end(7)
ll.printlist()
